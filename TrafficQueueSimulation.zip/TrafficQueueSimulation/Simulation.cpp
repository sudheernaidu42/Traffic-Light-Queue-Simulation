#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <unistd.h> // for sleep()
using namespace std;

// Vehicle structure
struct Vehicle {
    char number[15];
    int priority; // 1 for emergency, 0 for normal
    Vehicle* next;

    Vehicle(const char* num, int p) {
        strcpy(number, num);
        priority = p;
        next = nullptr;
    }
};

// Priority Queue implementation using linked list
class Queue {
private:
    Vehicle* front;
    Vehicle* rear;
    int size;

public:
    Queue() {
        front = rear = nullptr;
        size = 0;
    }

    void enqueue(const char* number, int priority) {
        Vehicle* v = new Vehicle(number, priority);
        if (priority == 1) {
            // Emergency vehicle - insert at front
            v->next = front;
            front = v;
            if (rear == nullptr) rear = v; // First vehicle case
        } else {
            // Normal vehicle - insert at rear
            if (rear == nullptr) {
                front = rear = v;
            } else {
                rear->next = v;
                rear = v;
            }
        }
        size++;
    }

    void dequeue() {
        if (front == nullptr)
            return;
        Vehicle* temp = front;
        front = front->next;
        delete temp;
        if (front == nullptr)
            rear = nullptr;
        size--;
    }

    const char* peek() {
        if (front == nullptr)
            return "Empty";
        return front->number;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    int getSize() {
        return size;
    }

    void displayQueue() {
        Vehicle* temp = front;
        while (temp != nullptr) {
            cout << temp->number;
            if (temp->priority == 1) cout << "(Emergency)";
            cout << " ";
            temp = temp->next;
        }
    }
};

// Traffic Light Simulation
class TrafficSystem {
private:
    Queue* lanes;
    int* durations;
    int laneCount;

public:
    TrafficSystem(int n, int* durs) {
        laneCount = n;
        lanes = new Queue[n];
        durations = new int[n];
        for (int i = 0; i < n; ++i) {
            durations[i] = durs[i];
        }
    }

    void addVehicleToLane(int lane, const char* number, int priority) {
        if (lane >= 0 && lane < laneCount)
            lanes[lane].enqueue(number, priority);
    }

    void simulateTraffic() {
        for (int i = 0; i < laneCount; ++i) {
            cout << "== Green Light for Lane " << i + 1 << " ==\n";
            int timeLeft = durations[i];
            while (timeLeft > 0 && !lanes[i].isEmpty()) {
                const char* vehicle = lanes[i].peek();
                cout << "Vehicle passed: " << vehicle << endl;
                lanes[i].dequeue();
                timeLeft--;
                sleep(1);
            }
            if (lanes[i].isEmpty()) {
                cout << "Lane " << i + 1 << " is empty.\n";
            } else {
                cout << "Red signal now. Vehicles still in lane: ";
                lanes[i].displayQueue();
                cout << endl;
            }
        }
    }

    ~TrafficSystem() {
        delete[] lanes;
        delete[] durations;
    }
};

// Main
int main() {
    std::ifstream in("input.txt");
    std::cin.rdbuf(in.rdbuf());
    int lanes, duration;

    cin >> lanes;
    int* durations = new int[lanes];
    for (int i = 0; i < lanes; ++i)
        cin >> durations[i];

    TrafficSystem system(lanes, durations);

    int laneId, priority;
    char number[15];

    while (true) {
        cin >> laneId;
        if (laneId == -1) break;
        cin >> number >> priority;
        system.addVehicleToLane(laneId, number, priority);
    }

    system.simulateTraffic();

    delete[] durations;
    return 0;
}
