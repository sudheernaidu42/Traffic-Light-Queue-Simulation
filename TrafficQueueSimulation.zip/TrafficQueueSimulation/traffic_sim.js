const express = require("express");
const fs = require("fs");
const { exec } = require("child_process");
const app = express();
const PORT = 3000;

app.use(express.static("public"));
app.use(express.text());

app.post("/simulate", (req, res) => {
    const input = req.body;
    fs.writeFileSync("input.txt", input);

    exec("g++ Simulation.cpp -o Simulation.exe && Simulation.exe", (err, stdout, stderr) => {
        if (err) {
            console.error("Error:", stderr);
            return res.status(500).send("Simulation failed.");
        }
        res.send(stdout);
    });
});

app.listen(PORT, () => {
    console.log(`🚦 Traffic Simulation running at http://localhost:${PORT}`);
});
